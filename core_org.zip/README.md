## Installation

This repository contains Laravel Admin Panel core code. If you want to set up a Laravel Admin, visit the [Laravel Admin Panel repository](https://github.com/balajidharma/basic-laravel-admin-panel) or [Laravel Vue Admin panel repository](https://github.com/balajidharma/laravel-vue-admin-panel).

## License

The Laravel Admin Panel is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
